#!/bin/bash

SERVER_IP="192.168.1.99"
BACKUP_PATH="$HOME/Projects/MobyDock/deploy/mobydock-production-sql.gz"

pg_dump -h "${SERVER_IP}" -p 5432 -U mobydock mobydock | gzip > "${BACKUP_PATH}"
